# 🏭 Controle de Produção Flask

Sistema de controle de produção pronto para deploy no Render.
